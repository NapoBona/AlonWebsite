export const socialLinks = [
  { name: "Spotify", url: "https://spotify.com/", icon: "spotify" },
  { name: "Apple Music", url: "https://music.apple.com/", icon: "appleMusic" },
  { name: "Instagram", url: "https://instagram.com/", icon: "instagram" },
  { name: "WhatsApp", url: "https://wa.me/", icon: "whatsapp" },
  { name: "Email", url: "mailto:artist@example.com", icon: "email" },
];

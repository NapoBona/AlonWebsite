export type Lang = "he" | "en";

export const translations = {
  nav: {
    home: { he: "בית", en: "Home" },
    bio: { he: "ביוגרפיה", en: "Biography" },
    gallery: { he: "גלריה", en: "Gallery" },
    events: { he: "אירועים", en: "Events" },
    contact: { he: "צור קשר", en: "Contact" },
  },
  hero: {
    name: { he: "שם האמן", en: "Artist Name" },
    tagline: { he: "מוזיקה מהלב של המדבר", en: "Music from the Heart of the Desert" },
  },
  bio: {
    title: { he: "ביוגרפיה", en: "Biography" },
    text: {
      he: "אמן מוזיקלי רב-תחומי המשלב צלילים מסורתיים עם מוזיקה עכשווית. במשך למעלה מעשור, הוא יוצר חוויות מוזיקליות ייחודיות המחברות בין תרבויות ומסורות. מסדנאות תיפוף במדבר ועד הופעות על במות בינלאומיות, המוזיקה שלו נוגעת בנשמה ומעוררת השראה.",
      en: "A multidisciplinary musical artist blending traditional sounds with contemporary music. For over a decade, creating unique musical experiences that connect cultures and traditions. From drumming workshops in the desert to performances on international stages, the music touches souls and inspires.",
    },
  },
  gallery: {
    title: { he: "גלריה", en: "Gallery" },
  },
  events: {
    title: { he: "אירועים קרובים", en: "Upcoming Events" },
    noEvents: { he: "אין אירועים קרובים כרגע", en: "No upcoming events at the moment" },
    details: { he: "פרטים", en: "Details" },
  },
  social: {
    title: { he: "בואו נתחבר", en: "Let's Connect" },
    subtitle: {
      he: "עקבו אחריי ברשתות החברתיות או צרו קשר ישירות",
      en: "Follow me on social media or reach out directly",
    },
  },
  player: {
    nowPlaying: { he: "מתנגן עכשיו", en: "Now Playing" },
  },
  themes: {
    desert: { he: "מדבר", en: "Desert" },
    night: { he: "לילה במדבר", en: "Night Desert" },
    ocean: { he: "אוקיינוס", en: "Ocean Mint" },
  },
} as const;

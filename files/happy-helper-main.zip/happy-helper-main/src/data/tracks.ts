export const tracks = [
  { title: { he: "שיר ראשון", en: "Track 1" }, artist: "Artist Name", src: "/audio/track1.mp3" },
  { title: { he: "שיר שני", en: "Track 2" }, artist: "Artist Name", src: "/audio/track2.mp3" },
  { title: { he: "שיר שלישי", en: "Track 3" }, artist: "Artist Name", src: "/audio/track3.mp3" },
];

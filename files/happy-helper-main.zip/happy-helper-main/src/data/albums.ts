import album1_1 from "@/assets/gallery/album1-1.jpg";
import album2_1 from "@/assets/gallery/album2-1.jpg";
import album3_1 from "@/assets/gallery/album3-1.jpg";
import album4_1 from "@/assets/gallery/album4-1.jpg";

export const albums = [
  {
    id: 1,
    name: { he: "סדנאות קצב", en: "Rhythm Workshops" },
    description: {
      he: "סדנאות תיפוף קבוצתיות במדבר — חיבור לקצב הפנימי דרך כלי הקשה מסורתיים.",
      en: "Group drumming workshops in the desert — connecting to inner rhythm through traditional percussion.",
    },
    images: [album1_1],
  },
  {
    id: 2,
    name: { he: "הופעות חיות", en: "Live Performances" },
    description: {
      he: "הופעות על במות ברחבי הארץ, מפסטיבלים גדולים ועד ערבים אינטימיים.",
      en: "Performances on stages across the country, from large festivals to intimate evenings.",
    },
    images: [album2_1],
  },
  {
    id: 3,
    name: { he: "טבע וצלילים", en: "Nature & Sounds" },
    description: {
      he: "מפגשי ריפוי בצלילים בטבע — קערות טיבטיות, גונגים וכלי נגינה אקוסטיים.",
      en: "Sound healing sessions in nature — Tibetan bowls, gongs, and acoustic instruments.",
    },
    images: [album3_1],
  },
  {
    id: 4,
    name: { he: "טקסים ואירועים", en: "Ceremonies & Events" },
    description: {
      he: "ליווי מוזיקלי לטקסים, חתונות ואירועים מיוחדים עם אנרגיה ייחודית.",
      en: "Musical accompaniment for ceremonies, weddings, and special events with unique energy.",
    },
    images: [album4_1],
  },
];

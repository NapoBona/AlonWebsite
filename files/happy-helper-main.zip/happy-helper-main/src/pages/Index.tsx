import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import BiographySection from "@/components/BiographySection";
import GallerySection from "@/components/GallerySection";
import EventsSection from "@/components/EventsSection";
import SocialSection from "@/components/SocialSection";
import FloatingPlayer from "@/components/FloatingPlayer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <BiographySection />
      <GallerySection />
      <EventsSection />
      <SocialSection />
      <FloatingPlayer />

      {/* Footer */}
      <footer className="py-8 text-center text-sm text-muted-foreground border-t border-border/30 bg-background">
        © {new Date().getFullYear()} Artist Name
      </footer>
    </div>
  );
};

export default Index;
